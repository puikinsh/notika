// Tawk.to Chat Widget - Disabled for testing
// Uncomment below to enable chat functionality
/*
(function () {
    "use strict";

    // Tawk.to Live Chat - Updated implementation
    try {
        var Tawk_API = Tawk_API || {};
        var Tawk_LoadStart = new Date();
        
        (function() {
            var s1 = document.createElement("script");
            var s0 = document.getElementsByTagName("script")[0];
            
            s1.async = true;
            s1.src = 'https://embed.tawk.to/59474840e9c6d324a47360f9/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            
            // Add error handling
            s1.onerror = function() {
                console.warn('Tawk.to chat widget failed to load');
            };
            
            if (s0 && s0.parentNode) {
                s0.parentNode.insertBefore(s1, s0);
            }
        })();
        
    } catch (error) {
        console.warn('Tawk.to initialization error:', error);
    }

})();
*/

console.log('Tawk.to chat disabled for testing - enable in tawk-chat.js if needed');